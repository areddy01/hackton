package com.adp.smartdoc.rest.ui;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.adp.smardoc.rest.ui.services.SmartDocumentService;
import com.adp.smardoc.rest.ui.entity.Document;

@RestController
@RequestMapping("/documents")
public class UploadController {

	// Save the uploaded file to this folder
	private static String UPLOADED_FOLDER = "./files/";

	private SmartDocumentService documentService = new SmartDocumentService();

	private int awardCount;

	private int resumeCount;

	private int personalCount;

	private int offerCount;

	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public String singleFileUpload(@RequestParam("file") MultipartFile file) {

		if (file.isEmpty()) {
			return "Unable to upload. File is empty.";
		}

		try {
			// Get the file and save it somewhere
			byte[] bytes = file.getBytes();
			Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
			Files.write(path, bytes);
			return "You successfully uploaded '" + file.getOriginalFilename() + "'";

		} catch (IOException e) {
			e.printStackTrace();
		}

		return "uploadStatus";
	}

	@RequestMapping(value = "/multipleFilesUpload", method = RequestMethod.POST)
	public String multiFileUpload(@RequestParam("files") MultipartFile[] files) {
		String fileName = null;
		String msg = "";

		if (files != null && files.length > 0) {
			try {
				msg = writeDocumentToServer(files);
			} catch (Exception e) {
				msg = "You failed to upload " + fileName + ": " + e.getMessage() + "<br/>";
			}
		} else {
			msg = "Unable to upload. File is empty.";
		}
		return msg;
	}

	@GetMapping("/getFiles")
	public List<Document> getFiles() {
		List<File> files = documentService.getFiles(UPLOADED_FOLDER);
		List<Document> docs = new ArrayList<Document>(files.size());

		if (files.size() > 0) {

			for (File file : files) {

				if (!file.isDirectory()) {
					String basePath = StringUtils.substringAfter(file.getAbsolutePath(), "files\\");
					String[] category = StringUtils.split(basePath, "\\");
					Document doc = new Document();
					if(category.length > 1){
						doc.setName(category[1]);
						doc.setCategory(category[0]);
					}else{
						doc.setName(category[0]);
						doc.setCategory("others");
					}
					doc.setPath(file.getAbsolutePath());
					doc.setAwardCount(awardCount);
					doc.setPersonalCount(personalCount);
					doc.setResumeCount(resumeCount);
					doc.setOfferCount(offerCount);
					docs.add(doc);
				}
			}

		}

		return docs;
	}

	private String writeDocumentToServer(MultipartFile[] files) throws IOException, FileNotFoundException {
		String msg = "";
		for (int i = 0; i < files.length; i++) {
			String fileName = files[i].getOriginalFilename();

			byte[] bytes = files[i].getBytes();
			File newUploadFile = new File(UPLOADED_FOLDER + fileName);
			BufferedOutputStream buffStream = new BufferedOutputStream(new FileOutputStream(newUploadFile));
			buffStream.write(bytes);
			buffStream.close();

			String category = documentService.processDocument(fileName);

			if (StringUtils.isNotEmpty(category)) {
				FileUtils.deleteQuietly(newUploadFile);
			}

			File directory = new File(UPLOADED_FOLDER + category);
			if (!directory.exists()) {
				directory.mkdir();
			}

			BufferedOutputStream buffStreamCate = new BufferedOutputStream(
					new FileOutputStream(new File(UPLOADED_FOLDER + category + "/" + fileName)));
			buffStreamCate.write(bytes);
			
			buffStreamCate.close();
		}
		msg = "You have successfully uploaded.";
		return msg;
	}

	@GetMapping("/uploadStatus")
	public String uploadStatus() {
		return "uploadStatus";
	}

}