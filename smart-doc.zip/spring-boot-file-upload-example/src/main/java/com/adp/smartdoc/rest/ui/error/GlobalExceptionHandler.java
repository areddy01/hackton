package com.adp.smartdoc.rest.ui.error;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MultipartException;

@ControllerAdvice
public class GlobalExceptionHandler {

/*    @ExceptionHandler(MultipartException.class)
    public String handleError1(MultipartException e, RedirectAttributes redirectAttributes) {
        return "redirect:/uploadStatus";

    }
*/
    @ExceptionHandler(MultipartException.class)
    public String handleError(MultipartException e) {
        return "errorPage";

    }

}
