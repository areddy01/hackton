package com.adp.smardoc.rest.ui.entity;

import java.util.List;

public class Category {

	private String category;
	private List<Document> documents;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public List<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}

}
