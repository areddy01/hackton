package com.adp.smardoc.text.helper;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ddf.EscherColorRef.SysIndexSource;

import com.swabunga.spell.engine.SpellDictionary;
import com.swabunga.spell.engine.SpellDictionaryHashMap;
import com.swabunga.spell.event.SpellCheckEvent;
import com.swabunga.spell.event.SpellCheckListener;
import com.swabunga.spell.event.SpellChecker;
import com.swabunga.spell.event.StringWordTokenizer;

public class EnglishSpellChecker implements SpellCheckListener {

	private static String dictFile = "dictionaries/english.0";
	private SpellChecker spellCheck = null;
	private String[] suggestion = null;

	public String[] spellCheck(String[] words) {
		SpellDictionary dictionary;
		try {
			dictionary = new SpellDictionaryHashMap(new File(dictFile));
			spellCheck = new SpellChecker(dictionary);
			int i  ;
			for(i = 0 ; i < words.length ; i ++ ){
				spellCheck.checkSpelling(new StringWordTokenizer(words[i]));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return suggestion;
	}

	@Override
	public void spellingError(SpellCheckEvent event) {
		List suggestions = event.getSuggestions();
		int index = 0;
		if (suggestions.size() > 0) {
			System.out.println("MISSPELT WORD: " + event.getInvalidWord());
			for (Iterator suggestedWord = suggestions.iterator(); suggestedWord.hasNext();) {
				suggestion[index] = suggestedWord.next().toString();
				index++;
			}
		} else {
			System.out.println("MISSPELT WORD: " + event.getInvalidWord());
			System.out.println("\tNo suggestions");
		}
	}

}
