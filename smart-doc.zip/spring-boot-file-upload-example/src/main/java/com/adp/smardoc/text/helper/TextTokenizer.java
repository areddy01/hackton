package com.adp.smardoc.text.helper;

import opennlp.tools.tokenize.SimpleTokenizer;

public class TextTokenizer {

	static SimpleTokenizer simpleTokenizer = SimpleTokenizer.INSTANCE;

	public static String[] tokenize(String sentence) {

		// Tokenizing the given sentence
		String tokens[] = simpleTokenizer.tokenize(sentence);

		// Printing the tokens
		/*for (String token : tokens) {
			System.out.println(token);
		}*/
		return tokens;
	}

/*	public static String removeStopWords(String text) throws Exception {
		Analyzer analyzer = new StopAnalyzer(EnglishAnalyzer.getDefaultStopSet());
		TokenStream tokenStream = analyzer.tokenStream(LuceneConstants.CONTENTS, new StringReader(text));
		CharTermAttribute charTermAttribute = tokenStream.addAttribute(CharTermAttribute.class);
		tokenStream.reset();
		StringBuilder sb = new StringBuilder();
		while (tokenStream.incrementToken()) {
			String term = charTermAttribute.toString();
			sb.append(term + " ");
		}
		return sb.toString();
	}

	public static String filterStopWords(String text) throws Exception {
		StandardTokenizer stdToken = new StandardTokenizer();
		stdToken.setReader(new StringReader(text));
		TokenStream tokenStream;

		tokenStream = new StopFilter(new ASCIIFoldingFilter(new ClassicFilter(new LowerCaseFilter(stdToken))),
				EnglishAnalyzer.getDefaultStopSet());
		tokenStream.reset();

		CharTermAttribute token = tokenStream.getAttribute(CharTermAttribute.class);
		while (tokenStream.incrementToken()) {
			return token.toString();
		}
		tokenStream.close();

		return StringUtils.EMPTY;
	}*/

}
