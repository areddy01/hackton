package com.adp.smardoc.text.engines;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.lang.StringUtils;
import org.knallgrau.utils.textcat.TextCategorizer;

import com.uttesh.exude.ExudeData;
import com.uttesh.exude.exception.InvalidDataException;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract1;
import net.sourceforge.tess4j.Word;

public class ImageTextEngine {

	private static final String DOCUMENT_ROOT_PATH = "./files/";

	private File imageFile = null;

	private String category = StringUtils.EMPTY;

	private String filteredClassWords = StringUtils.EMPTY;

	public ImageTextEngine(String fileName) {
		imageFile = new File(DOCUMENT_ROOT_PATH + fileName);
	}

	public void process() {
		ITesseract instance = new Tesseract1(); // JNA Interface Mapping
		try {
			List<Word> imgWords = instance.getWords(ImageIO.read(imageFile), 2);
			filteredClassWords = filter(imgWords);
			//System.out.println(filteredClassWords);
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}

	private String filter(List<Word> imageWords) {
		ExudeData exudeData = ExudeData.getInstance();
		String withNoStopWords = null;
		for (Word word : imageWords) {
			try {
				withNoStopWords = exudeData.filterStoppings(word.getText());
			} catch (InvalidDataException e) {
				System.err.println(e.getMessage());
			}
		}
		return withNoStopWords;
	}

	public String getCategory() {
		TextCategorizer guesser = new TextCategorizer();
		guesser.setConfFile("footprint.conf");
		category = guesser.categorize(filteredClassWords);
		System.out.println( category);
		return category;
	}

}
